# *types/* 目录

本目录为自定义的扩展类型的目录

* `\SM3\types\BitString`
    比特串 类型
    * `\SM3\types\Word`
        字 类型